-- MySQL dump 10.13  Distrib 5.5.42-37.1, for Linux (x86_64)
--
-- Host: localhost    Database: cryotek_library
-- ------------------------------------------------------
-- Server version	5.5.42-37.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bookInfo`
--

DROP TABLE IF EXISTS `bookInfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bookInfo` (
  `Title` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `Author` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `ID` int(30) NOT NULL,
  `Issue` int(3) NOT NULL COMMENT 'Book Issue Number',
  `Publication` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Availability` varchar(12) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Is Book Available?',
  `Selected` int(1) NOT NULL,
  `bookPDF` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `BookCover` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Has attributes to store book and its info';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookInfo`
--

LOCK TABLES `bookInfo` WRITE;
/*!40000 ALTER TABLE `bookInfo` DISABLE KEYS */;
INSERT INTO `bookInfo` (`Title`, `Author`, `ID`, `Issue`, `Publication`, `Availability`, `Selected`, `bookPDF`, `BookCover`) VALUES ('A Wonder Book','Nathaniel Hawthorne',1006,1,'Trwheeler','In Stock',0,'wonder_book.pdf','NaN'),('The Wilde Tales','Oscar Wilde',1005,1,'N.A','In Stock',0,'wilde_tales.pdf','NaN'),('Grimm Tales','Jacob and Wilhelm Grimm',1003,1,'TRW Stories','In Stock',0,'grimm_tales.pdf','NaN'),('Jataka tales','Ellen C. Babbit',1004,1,'Trwheeler','In Stock',0,'jataka_tales.pdf','NaN'),('Robin Hood','J. Walker McSpadden',1002,1,'TRW Stories','Out To user',0,'robin_hood.pdf','NaN'),('Arabian Nights','Tahir Shah',1001,1,'Doubleday','In Stock',0,'arabian_nights.pdf','NaN');
/*!40000 ALTER TABLE `bookInfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userCart`
--

DROP TABLE IF EXISTS `userCart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userCart` (
  `Title` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Author` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ID` int(8) DEFAULT NULL,
  `CheckoutDate` date DEFAULT NULL,
  `ReturnDate` date DEFAULT NULL,
  `checkedOut` int(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userCart`
--

LOCK TABLES `userCart` WRITE;
/*!40000 ALTER TABLE `userCart` DISABLE KEYS */;
INSERT INTO `userCart` (`Title`, `Author`, `ID`, `CheckoutDate`, `ReturnDate`, `checkedOut`) VALUES ('Robin Hood','J. Walker McSpadden',1002,'2015-08-07','2015-01-25',1);
/*!40000 ALTER TABLE `userCart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userInfo`
--

DROP TABLE IF EXISTS `userInfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userInfo` (
  `First Name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Last Name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Username` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Password` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `User Type` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `Books Out` tinyint(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userInfo`
--

LOCK TABLES `userInfo` WRITE;
/*!40000 ALTER TABLE `userInfo` DISABLE KEYS */;
INSERT INTO `userInfo` (`First Name`, `Last Name`, `Username`, `Password`, `User Type`, `Books Out`) VALUES ('admin','admin','admin','admin','admin',0),('user First','user Last','user','user','user',0),('first name','lname','aaa','bbb','user',0),('tyler','w','twalla','twalla','user',0),('test','lastname','test','test77','user',0);
/*!40000 ALTER TABLE `userInfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'cryotek_library'
--

--
-- Dumping routines for database 'cryotek_library'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-09-13 18:43:52
