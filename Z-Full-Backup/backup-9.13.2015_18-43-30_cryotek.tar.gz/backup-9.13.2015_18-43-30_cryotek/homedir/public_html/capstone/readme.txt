source for main image:

http://back-grounds.com/file/643/2880x1800/crop/tree-in-a-field.jpg