<?php

require 'Slim/Slim.php';
\Slim\Slim::registerAutoloader();

$app = new \Slim\Slim();

$app->get('/estimote', 'GetEstimotes'); // Using Get HTTP Method and process getUsers function
$app->get('/estimote/:id',    'GetEstimote'); // Using Get HTTP Method and process getUser function
$app->get('/estimote/search/:query', 'FindEstimote'); // Using Get HTTP Method and process findByName function
$app->get('/logs','GetLogs');
$app->get('/questions', 'SetQuestion');
$app->post('/logs','PostLogs');
$app->post('/estimote', 'AddEstimote');
$app->put('/estimote/:id', 'UpdateEstimote'); // Using Put HTTP Method and process updateUser function
$app->delete('/estimote/:id',    'DeleteEstimote'); // Using Delete HTTP Method and process deleteUser function
$app->run();


function getConnection(){

    try {
        $db_username = "cryotek_dru";
        $db_password = "dicejar77";
        $conn = new PDO('mysql:host=localhost;dbname=cryotek_Dr_U', $db_username, $db_password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
 
    } catch(PDOException $e) {
        echo 'ERROR: ' . $e->getMessage();
    }
    return $conn;
}



function GetEstimotes() {
    $sql_query = "SELECT `Major`,`Minor`,`Name`,`Exhibit` FROM dru_estimote ORDER BY Name";
    try {
        $dbCon = getConnection();
        $stmt   = $dbCon->query($sql_query);
        $users  = $stmt->fetchAll(PDO::FETCH_OBJ);
        $dbCon = null;
        echo '{"Estimotes": ' . json_encode($users, JSON_PRETTY_PRINT) . '}';
        //echo '<pre>' . print_r($users, true) . '</pre>';
    }
    catch(PDOException $e) {
        echo '{"error":{"text":'. $e->getMessage() .'}}';
    }    
}

function GetLogs() {
    $sql_query = "SELECT * FROM dru_logs ORDER BY date";
    try {
        $dbCon = getConnection();
        $stmt   = $dbCon->query($sql_query);
        $users  = $stmt->fetchAll(PDO::FETCH_OBJ);
        $dbCon = null;
        echo '{"Logs": ' . json_encode($users, JSON_PRETTY_PRINT) . '}';
        //echo '<pre>' . print_r($users, true) . '</pre>';
    }
    catch(PDOException $e) {
        echo '{"error":{"text":'. $e->getMessage() .'}}';
    }    
}

function GetEstimote($id) {
    $sql = "SELECT `Major`,`Minor`,`Name`,`Exhibit` FROM dru_estimote WHERE Major=:id";
    try {
        $dbCon = getConnection();
        $stmt = $dbCon->prepare($sql);  
        $stmt->bindParam("id", $id);
        $stmt->execute();
        $user = $stmt->fetchObject();  
        $dbCon = null;
        echo json_encode($user, JSON_PRETTY_PRINT); 
        //echo '<pre>' . print_r($user, true) . '</pre>';
    } catch(PDOException $e) {
        echo '{"error":{"text":'. $e->getMessage() .'}}'; 
    }
}

function FindEstimote($query) {
    $sql = "SELECT * FROM dru_estimote WHERE UPPER(Name) LIKE :query ORDER BY Name";
    try {
        $dbCon = getConnection();
        $stmt = $dbCon->prepare($sql);
        $query = "%".$query."%";
        $stmt->bindParam("query", $query);
        $stmt->execute();
        $users = $stmt->fetchAll(PDO::FETCH_OBJ);
        $dbCon = null;
        echo '{"user": ' . json_encode($users, JSON_PRETTY_PRINT) . '}';
        //echo '<pre>' . print_r($users, true) . '</pre>';
    } catch(PDOException $e) {
        echo '{"error":{"text":'. $e->getMessage() .'}}'; 
    }
}

function SetQuestion() {
    global $app;
    $req = $app->request(); // Getting parameter with names
    $paramMajor = $req->params('Question'); // Getting parameter with names
/*
"SELECT aID, qID, question, MATCH(question) AGAINST('" . stripslashes 
	(str_replace ("&quot;", "\"", ($_POST['input']))) . "' IN NATURAL LANGUAGE MODE) 
AS score FROM  dru_questions WHERE MATCH (question) AGAINST 
('" . stripslashes (str_replace ("&quot;", "\"", ($_POST['input']))) . "' 
	IN NATURAL LANGUAGE MODE) ORDER BY  `score` DESC LIMIT 0 , 10"
	*/

    $sql = "SELECT `aID`, `qID` FROM dru_questions WHERE MATCH (question) AGAINST ('" . stripslashes (str_replace ("&quot;", "\"", $paramMajor)) . "' IN NATURAL LANGUAGE MODE)";
    try {
        $dbCon = getConnection();
        $stmt = $dbCon->prepare($sql);  
        $stmt->bindParam("Question", $paramMajor);
        //$stmt->bindParam("ip", $_SERVER['REMOTE_ADDR']);
        $stmt->execute();
        $user = $stmt->fetchObject();

        //$dbCon = null;
        $data = $user->aID;
        $sql = "SELECT answer FROM dru_answers WHERE aID=$data";

        $stmt = $dbCon->prepare($sql);  
        //$stmt->bindParam("ip", $_SERVER['REMOTE_ADDR']);
        $stmt->execute();
        $fin = $stmt->fetchObject();

        //GetAnswer($user);
        $dbCon = null;
        $send = array('answer' => $fin->answer, 'aID' => $data, 'qID' => $user->qID);
        echo json_encode($send, JSON_PRETTY_PRINT); 
        //echo '<pre>' . print_r($user, true) . '</pre>';
    } catch(PDOException $e) {
        echo ""; 
    }
}


function AddEstimote() {
    global $app;
    $req = $app->request(); // Getting parameter with names
    $paramMajor = $req->params('Major'); // Getting parameter with names
    $paramMinor = $req->params('Minor'); // Getting parameter with names
    $paramName = $req->params('Name'); // Getting parameter with names
    $paramExhibit = $req->params('Exhibit'); // Getting parameter with names

    $sql = "INSERT INTO dru_estimote (`Major`,`Minor`,`Name`, `Exhibit`) VALUES (:Major, :Minor, :Name, :Exhibit)";
    try {
        $dbCon = getConnection();
        $stmt = $dbCon->prepare($sql);  
        $stmt->bindParam("Major", $paramMajor);
        $stmt->bindParam("Minor", $paramMinor);
        $stmt->bindParam("Name", $paramName);
        $stmt->bindParam("Exhibit", $paramExhibit);
        //$stmt->bindParam("ip", $_SERVER['REMOTE_ADDR']);
        $stmt->execute();
        $user = $dbCon->lastInsertId();
        $dbCon = null;
        echo json_encode($user, JSON_PRETTY_PRINT); 
        //echo '<pre>' . print_r($user, true) . '</pre>';
    } catch(PDOException $e) {
        echo '{"error":{"text":'. $e->getMessage() .'}}'; 
    }
}

function PostLogs() {
    global $app;
    $req = $app->request(); // Getting parameter with names
    //$p_date = $req->params('date'); // Getting parameter with names
    $p_aID = $req->params('aID_fetched'); // Getting parameter with names
    $p_qID = $req->params('qID_fetched'); // Getting parameter with names
    $p_qTyped = $req->params('qTyped'); // Getting parameter with names
    //$p_qTime = $req->params('qTime'); // Getting parameter with names
    $p_GPS = $req->params('GPS'); // Getting parameter with names
    $p_iBeacon = $req->params('iBeacons'); // Getting parameter with names
    $p_devID = $req->params('deviceID'); // Getting parameter with names

    $sql = "INSERT INTO dru_logs (`aID_fetched`,`qID_fetched`, `qTyped`, `GPS`, `iBeacons`, `deviceID`) VALUES (:aID_fetched, :qID_fetched, :qTyped, :GPS, :iBeacons, :deviceID)";
    try {
        $dbCon = getConnection();
        $stmt = $dbCon->prepare($sql);  
        //$stmt->bindParam("date", $p_date);
        $stmt->bindParam("aID_fetched", $p_aID);
        $stmt->bindParam("qID_fetched", $p_qID);
        $stmt->bindParam("qTyped", $p_qTyped);
        //$stmt->bindParam("qTime", $p_qTime);
        $stmt->bindParam("GPS", $p_GPS);
        $stmt->bindParam("iBeacons", $p_iBeacon);
        $stmt->bindParam("deviceID", $p_devID);
        //$stmt->bindParam("ip", $_SERVER['REMOTE_ADDR']);
        $stmt->execute();
        $user = $dbCon->lastInsertId();
        $dbCon = null;
        echo json_encode($user, JSON_PRETTY_PRINT); 
        //echo '<pre>' . print_r($user, true) . '</pre>';
    } catch(PDOException $e) {
        echo '{"error":{"text":'. $e->getMessage() .'}}'; 
    }
}

function UpdateEstimote($id) {
	global $app;
    $req = $app->request();
    $paramName = $req->params('Name');
    $paramExhibit = $req->params('Exhibit');

    $sql = "UPDATE dru_estimote SET Name=:Name, Exhibit=:Exhibit WHERE Major=:id";
    try {
        $dbCon = getConnection();
        $stmt = $dbCon->prepare($sql);  
        $stmt->bindParam("Name", $paramName);
        $stmt->bindParam("Exhibit", $paramExhibit);
        $stmt->bindParam("id", $id);
        $status = $stmt->execute();

        $dbCon = null;
        echo json_encode($status, JSON_PRETTY_PRINT); 
        //echo '<pre>' . print_r($status, true) . '</pre>';
    } catch(PDOException $e) {
        echo '{"error":{"text":'. $e->getMessage() .'}}'; 
    }
}

function DeleteEstimote($id) {
    $sql = "DELETE FROM dru_estimote WHERE Major=:id";
    try {
        $dbCon = getConnection();
        $stmt = $dbCon->prepare($sql);  
        $stmt->bindParam("id", $id);
        $status = $stmt->execute();
        $dbCon = null;
        echo json_encode($status, JSON_PRETTY_PRINT);
        //echo '<pre>' . print_r($status, true) . '</pre>';
    } catch(PDOException $e) {
        echo '{"error":{"text":'. $e->getMessage() .'}}'; 
    }
}


?>