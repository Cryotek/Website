var dir_14cedd36051f805fc37b92892fed2a75 =
[
    [ "obj", "dir_bc77e0a6d68192860de2fcfe022ba4b3.html", "dir_bc77e0a6d68192860de2fcfe022ba4b3" ],
    [ "Properties", "dir_38b64d23c3695b8b14d5eaadae7fa8fd.html", "dir_38b64d23c3695b8b14d5eaadae7fa8fd" ],
    [ "AppDelegate.cs", "_app_delegate_8cs.html", [
      [ "AppDelegate", "class_dr_universe_1_1_app_delegate.html", "class_dr_universe_1_1_app_delegate" ]
    ] ],
    [ "AskPanelController.cs", "_ask_panel_controller_8cs.html", [
      [ "AskPanelController", "class_dr_universe_1_1_ask_panel_controller.html", "class_dr_universe_1_1_ask_panel_controller" ]
    ] ],
    [ "AskPanelController.designer.cs", "_ask_panel_controller_8designer_8cs.html", [
      [ "AskPanelController", "class_dr_universe_1_1_ask_panel_controller.html", "class_dr_universe_1_1_ask_panel_controller" ]
    ] ],
    [ "Bubble.cs", "_bubble_8cs.html", [
      [ "BubbleCell", "class_dr_universe_1_1_bubble_cell.html", "class_dr_universe_1_1_bubble_cell" ],
      [ "ChatBubble", "class_dr_universe_1_1_chat_bubble.html", "class_dr_universe_1_1_chat_bubble" ]
    ] ],
    [ "ClassInit.cs", "_class_init_8cs.html", [
      [ "Question", "class_dr_universe_1_1_question.html", "class_dr_universe_1_1_question" ],
      [ "Answer", "class_dr_universe_1_1_answer.html", "class_dr_universe_1_1_answer" ],
      [ "Estimote", "class_dr_universe_1_1_estimote.html", "class_dr_universe_1_1_estimote" ],
      [ "Exhibit", "class_dr_universe_1_1_exhibit.html", "class_dr_universe_1_1_exhibit" ],
      [ "Log", "class_dr_universe_1_1_log.html", "class_dr_universe_1_1_log" ],
      [ "Response", "class_dr_universe_1_1_response.html", "class_dr_universe_1_1_response" ]
    ] ],
    [ "DBHandler.cs", "_d_b_handler_8cs.html", null ],
    [ "LogHandler.cs", "_log_handler_8cs.html", null ],
    [ "LogTesting.cs", "_log_testing_8cs.html", [
      [ "LogTesting", "class_dr_universe_1_1_log_testing.html", "class_dr_universe_1_1_log_testing" ],
      [ "StatusPickerViewModel", "class_dr_universe_1_1_log_testing_1_1_status_picker_view_model.html", "class_dr_universe_1_1_log_testing_1_1_status_picker_view_model" ]
    ] ],
    [ "LuceneSearch.cs", "_lucene_search_8cs.html", null ],
    [ "Main.cs", "_main_8cs.html", [
      [ "Application", "class_dr_universe_1_1_application.html", null ]
    ] ],
    [ "MenuController.cs", "_menu_controller_8cs.html", [
      [ "MenuController", "class_dr_universe_1_1_menu_controller.html", "class_dr_universe_1_1_menu_controller" ]
    ] ],
    [ "MenuController.designer.cs", "_menu_controller_8designer_8cs.html", [
      [ "MenuController", "class_dr_universe_1_1_menu_controller.html", "class_dr_universe_1_1_menu_controller" ]
    ] ],
    [ "Network.cs", "_network_8cs.html", "_network_8cs" ],
    [ "QuestPanelController.cs", "_quest_panel_controller_8cs.html", [
      [ "QuestPanelController", "class_dr_universe_1_1_quest_panel_controller.html", "class_dr_universe_1_1_quest_panel_controller" ]
    ] ],
    [ "QuestPanelController.designer.cs", "_quest_panel_controller_8designer_8cs.html", [
      [ "QuestPanelController", "class_dr_universe_1_1_quest_panel_controller.html", "class_dr_universe_1_1_quest_panel_controller" ]
    ] ],
    [ "RootViewController.cs", "_root_view_controller_8cs.html", [
      [ "RootViewController", "class_dr_universe_1_1_root_view_controller.html", "class_dr_universe_1_1_root_view_controller" ]
    ] ],
    [ "RootViewController.designer.cs", "_root_view_controller_8designer_8cs.html", [
      [ "RootViewController", "class_dr_universe_1_1_root_view_controller.html", "class_dr_universe_1_1_root_view_controller" ]
    ] ],
    [ "SlideMenuController.designer.cs", "_slide_menu_controller_8designer_8cs.html", [
      [ "SlideMenuController", "class_dr_universe_1_1_slide_menu_controller.html", "class_dr_universe_1_1_slide_menu_controller" ]
    ] ],
    [ "SlideMenuViewController.cs", "_slide_menu_view_controller_8cs.html", [
      [ "SlideMenuViewController", "class_dr_universe_1_1_slide_menu_view_controller.html", "class_dr_universe_1_1_slide_menu_view_controller" ]
    ] ],
    [ "SlideMenuViewController.designer.cs", "_slide_menu_view_controller_8designer_8cs.html", [
      [ "SlideMenuViewController", "class_dr_universe_1_1_slide_menu_view_controller.html", "class_dr_universe_1_1_slide_menu_view_controller" ]
    ] ],
    [ "ViewScroll.cs", "_view_scroll_8cs.html", [
      [ "ViewScroll", "class_dr_universe_1_1_view_scroll.html", "class_dr_universe_1_1_view_scroll" ]
    ] ]
];