var _network_8cs =
[
    [ "NetworkStatus", "_network_8cs.html#a56ca9cb4ac23aa6c4022a2e3548337f8", [
      [ "NotReachable", "_network_8cs.html#a56ca9cb4ac23aa6c4022a2e3548337f8aa74377c8265d2a2a5a23e9eb15e8f5c2", null ],
      [ "ReachableViaCarrierDataNetwork", "_network_8cs.html#a56ca9cb4ac23aa6c4022a2e3548337f8ae658105bd3fb4bbf5519e5582d7382a3", null ],
      [ "ReachableViaWiFiNetwork", "_network_8cs.html#a56ca9cb4ac23aa6c4022a2e3548337f8aca7add819b86128c84e9b5bfdc483059", null ]
    ] ]
];