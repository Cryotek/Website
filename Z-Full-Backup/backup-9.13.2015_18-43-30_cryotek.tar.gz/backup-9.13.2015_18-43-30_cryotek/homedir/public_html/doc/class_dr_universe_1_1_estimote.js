var class_dr_universe_1_1_estimote =
[
    [ "description", "class_dr_universe_1_1_estimote.html#a012327424172c8653fcc65624cea23b0", null ],
    [ "id", "class_dr_universe_1_1_estimote.html#af843cc8ccb93d21d979985831cd37296", null ],
    [ "major", "class_dr_universe_1_1_estimote.html#a6f88bc0c3ccea0da06596d8d6b81a870", null ],
    [ "minor", "class_dr_universe_1_1_estimote.html#ab3713a1258292bfbbfdcb8040faa787c", null ],
    [ "name", "class_dr_universe_1_1_estimote.html#a563c22e8d5074034a8066c92c0ad2d0b", null ]
];