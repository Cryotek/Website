var class_dr_universe_1_1_menu_controller =
[
    [ "MenuController", "class_dr_universe_1_1_menu_controller.html#adb8d3a417990df7503728cccc512e418", null ],
    [ "ReleaseDesignerOutlets", "class_dr_universe_1_1_menu_controller.html#a6e1940d2b2f72f1b278c4a80126d1465", null ],
    [ "ViewDidLoad", "class_dr_universe_1_1_menu_controller.html#a064c02072e0152ab6a9560e536ac5add", null ]
];