var class_dr_universe_1_1_answer =
[
    [ "aID", "class_dr_universe_1_1_answer.html#a9ceedc982734a05def9684c363ac6fde", null ],
    [ "answer", "class_dr_universe_1_1_answer.html#a8dc1d56daa29e323f2c3c1e361dede61", null ],
    [ "content_area", "class_dr_universe_1_1_answer.html#a4811c207ee193b7fe202215e6576d446", null ],
    [ "es_answer", "class_dr_universe_1_1_answer.html#a5a3554e06b15398bd1797334f4669fbf", null ],
    [ "source", "class_dr_universe_1_1_answer.html#a65b569589ee9477fbf19a658062cf093", null ],
    [ "time_sensitive", "class_dr_universe_1_1_answer.html#ab75f1b484798b6d408659e437f6b21f7", null ]
];