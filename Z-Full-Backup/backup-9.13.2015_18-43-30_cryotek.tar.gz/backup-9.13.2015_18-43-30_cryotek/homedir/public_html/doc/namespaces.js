var namespaces =
[
    [ "DrUniverse", "namespace_dr_universe.html", null ]
];