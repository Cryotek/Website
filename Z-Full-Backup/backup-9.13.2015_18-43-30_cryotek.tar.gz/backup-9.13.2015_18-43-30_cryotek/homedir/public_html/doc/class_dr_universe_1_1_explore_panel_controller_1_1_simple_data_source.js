var class_dr_universe_1_1_explore_panel_controller_1_1_simple_data_source =
[
    [ "SimpleDataSource", "class_dr_universe_1_1_explore_panel_controller_1_1_simple_data_source.html#a94e0b7a23f6ee63228f20c285e24f53d", null ],
    [ "NumberOfItems", "class_dr_universe_1_1_explore_panel_controller_1_1_simple_data_source.html#a4d88d3c9da19606e290c614cdb344acb", null ],
    [ "ViewForItem", "class_dr_universe_1_1_explore_panel_controller_1_1_simple_data_source.html#a808dc134a7c87e6b5380efb588019d58", null ],
    [ "vc", "class_dr_universe_1_1_explore_panel_controller_1_1_simple_data_source.html#a86ea27de1454bee52ee3ab81ef20171b", null ]
];