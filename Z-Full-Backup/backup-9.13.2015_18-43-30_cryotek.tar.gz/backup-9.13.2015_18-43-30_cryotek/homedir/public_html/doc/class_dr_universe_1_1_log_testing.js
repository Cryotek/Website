var class_dr_universe_1_1_log_testing =
[
    [ "StatusPickerViewModel", "class_dr_universe_1_1_log_testing_1_1_status_picker_view_model.html", "class_dr_universe_1_1_log_testing_1_1_status_picker_view_model" ],
    [ "LogTesting", "class_dr_universe_1_1_log_testing.html#a1662c312ce97892300390bf65f61f35f", null ],
    [ "ViewDidLoad", "class_dr_universe_1_1_log_testing.html#af3f4cc3a58401cf7478928da920a6c86", null ],
    [ "selectedEstimote", "class_dr_universe_1_1_log_testing.html#afebfc15509d5374ffd622c518b1fd86f", null ],
    [ "txtExhibit", "class_dr_universe_1_1_log_testing.html#a7a25acf366bb87d0562400aac05f7e45", null ]
];