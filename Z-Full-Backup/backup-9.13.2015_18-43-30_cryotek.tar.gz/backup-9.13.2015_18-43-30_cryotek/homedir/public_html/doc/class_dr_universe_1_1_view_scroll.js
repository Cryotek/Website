var class_dr_universe_1_1_view_scroll =
[
    [ "ViewScroll", "class_dr_universe_1_1_view_scroll.html#a3090df06961afca84cb0427d1538fdd5", null ],
    [ "ViewScroll", "class_dr_universe_1_1_view_scroll.html#ab33da358069612fa295ffc4b6fcb68c8", null ],
    [ "KeyBoardDownNotification", "class_dr_universe_1_1_view_scroll.html#a1c2c54a557f8bcd883622a3f1dd55c2c", null ],
    [ "KeyBoardUpNotification", "class_dr_universe_1_1_view_scroll.html#a137cd557d78b37f7da4e8a34d95e8f43", null ],
    [ "ScrollTheView", "class_dr_universe_1_1_view_scroll.html#ac01312181fcf37fe60a16d7ab3cf3e30", null ],
    [ "ViewDidLoad", "class_dr_universe_1_1_view_scroll.html#add2f786099a7f0fb270b9cf00a77bcb3", null ],
    [ "_activeview", "class_dr_universe_1_1_view_scroll.html#ae38fe3d82c5436669537c28deae787f3", null ],
    [ "_bottom", "class_dr_universe_1_1_view_scroll.html#aaafbbad6a3d2b78ad3d752b1e92b5fba", null ],
    [ "_moveViewUp", "class_dr_universe_1_1_view_scroll.html#a9beff4824dba0773556a7b671e6cff27", null ],
    [ "_offset", "class_dr_universe_1_1_view_scroll.html#a894c5dd4e31b0cbd3119e939c5dee375", null ],
    [ "_scrollAmount", "class_dr_universe_1_1_view_scroll.html#a24f70cbecb4abc8bc64ac98d9d60758d", null ],
    [ "keyUP", "class_dr_universe_1_1_view_scroll.html#a5de0490f2bb3addc338fee48a0587705", null ]
];