var class_dr_universe_1_1_log =
[
    [ "Log", "class_dr_universe_1_1_log.html#a275cf47d80bcfa490e900f60fd12fb1b", null ],
    [ "Log", "class_dr_universe_1_1_log.html#acbbe6b4b7aa386db29d9620ff00e80e9", null ],
    [ "aID_fetched", "class_dr_universe_1_1_log.html#ae7ac17bf030c6dc9ac495bb3cf59be2c", null ],
    [ "date", "class_dr_universe_1_1_log.html#aa0231b602af94297b39bbbda029c78c1", null ],
    [ "device_id", "class_dr_universe_1_1_log.html#a5329a06ca74f3e58a8acb17679019394", null ],
    [ "estimote_exhibit", "class_dr_universe_1_1_log.html#a9268b6ef2e7829280af093f00e65f95a", null ],
    [ "estimote_id", "class_dr_universe_1_1_log.html#a7abe98a2a889bbc64411d8d07544bc64", null ],
    [ "GPS", "class_dr_universe_1_1_log.html#a5a60a8f2f46c5619476aacdd9ae82498", null ],
    [ "qID_fetched", "class_dr_universe_1_1_log.html#a46cbbe8ad05c607c56d21956c744a99e", null ],
    [ "qTime", "class_dr_universe_1_1_log.html#acb9e2d9547f254c82c08ad0ab34fad47", null ],
    [ "qTyped", "class_dr_universe_1_1_log.html#aefe5c7824e7a18a6c6afa8bbaa90c6e5", null ]
];