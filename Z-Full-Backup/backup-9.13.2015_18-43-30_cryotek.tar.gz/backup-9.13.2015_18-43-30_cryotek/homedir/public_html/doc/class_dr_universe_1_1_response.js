var class_dr_universe_1_1_response =
[
    [ "Response", "class_dr_universe_1_1_response.html#a04c0013e15789a8dcdb871fcf3b0bfda", null ],
    [ "Response", "class_dr_universe_1_1_response.html#a93165467a1095f56a120afdad564b3d8", null ],
    [ "answer", "class_dr_universe_1_1_response.html#a1a7192bff91020b20b9e84889344dec1", null ],
    [ "answer_id", "class_dr_universe_1_1_response.html#a33cd57da3ff6088709981b7cf96662a4", null ],
    [ "question", "class_dr_universe_1_1_response.html#a5be532e2252ebaefe92b2a8855e4a358", null ],
    [ "question_id", "class_dr_universe_1_1_response.html#a346d188f6f84420e92781eb0e70ca014", null ]
];