var dir_3ad628a8f609821ea111b621878b0569 =
[
    [ "DrUniverse", "dir_0940abf48358dd5ae803f5686e3e5176.html", "dir_0940abf48358dd5ae803f5686e3e5176" ]
];