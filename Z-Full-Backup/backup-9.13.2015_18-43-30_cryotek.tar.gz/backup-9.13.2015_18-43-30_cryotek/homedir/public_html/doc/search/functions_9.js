var searchData=
[
  ['layoutsubviews',['LayoutSubviews',['../class_dr_universe_1_1_bubble_cell.html#a5a2a40fc3f4e9f8e22c676bc53b2328d',1,'DrUniverse::BubbleCell']]],
  ['log',['Log',['../class_dr_universe_1_1_log.html#a275cf47d80bcfa490e900f60fd12fb1b',1,'DrUniverse.Log.Log()'],['../class_dr_universe_1_1_log.html#acbbe6b4b7aa386db29d9620ff00e80e9',1,'DrUniverse.Log.Log(Response r, Estimote e)']]],
  ['logtesting',['LogTesting',['../class_dr_universe_1_1_log_testing.html#a1662c312ce97892300390bf65f61f35f',1,'DrUniverse::LogTesting']]]
];
