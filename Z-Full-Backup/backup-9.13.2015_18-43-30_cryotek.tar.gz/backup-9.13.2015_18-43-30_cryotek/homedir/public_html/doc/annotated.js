var annotated =
[
    [ "DrUniverse", "namespace_dr_universe.html", "namespace_dr_universe" ]
];