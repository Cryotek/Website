var hierarchy =
[
    [ "DrUniverse.AdminWebPage", "class_dr_universe_1_1_admin_web_page.html", null ],
    [ "DrUniverse.Answer", "class_dr_universe_1_1_answer.html", null ],
    [ "DrUniverse.Application", "class_dr_universe_1_1_application.html", null ],
    [ "DrUniverse.AskMenuController", "class_dr_universe_1_1_ask_menu_controller.html", null ],
    [ "DrUniverse.AskPanelTutorial", "class_dr_universe_1_1_ask_panel_tutorial.html", null ],
    [ "CarouselViewDataSource", null, [
      [ "DrUniverse.ExplorePanelController.SimpleDataSource", "class_dr_universe_1_1_explore_panel_controller_1_1_simple_data_source.html", null ]
    ] ],
    [ "CarouselViewDelegate", null, [
      [ "DrUniverse.ExplorePanelController.SimpleDelegate", "class_dr_universe_1_1_explore_panel_controller_1_1_simple_delegate.html", null ]
    ] ],
    [ "CSMenuController", null, [
      [ "DrUniverse.AskSlideMenuController", "class_dr_universe_1_1_ask_slide_menu_controller.html", null ],
      [ "DrUniverse.ExploreSlideMenuController", "class_dr_universe_1_1_explore_slide_menu_controller.html", null ],
      [ "DrUniverse.QuestSlideMenuController", "class_dr_universe_1_1_quest_slide_menu_controller.html", null ]
    ] ],
    [ "Element", null, [
      [ "DrUniverse.ChatBubble", "class_dr_universe_1_1_chat_bubble.html", null ]
    ] ],
    [ "DrUniverse.Estimote", "class_dr_universe_1_1_estimote.html", null ],
    [ "DrUniverse.Exhibit", "class_dr_universe_1_1_exhibit.html", null ],
    [ "IElementSizing", null, [
      [ "DrUniverse.ChatBubble", "class_dr_universe_1_1_chat_bubble.html", null ]
    ] ],
    [ "DrUniverse.Log", "class_dr_universe_1_1_log.html", null ],
    [ "DrUniverse.Question", "class_dr_universe_1_1_question.html", null ],
    [ "DrUniverse.QuestionBar", "class_dr_universe_1_1_question_bar.html", null ],
    [ "DrUniverse.QuestScene", "class_dr_universe_1_1_quest_scene.html", null ],
    [ "DrUniverse.Response", "class_dr_universe_1_1_response.html", null ],
    [ "DrUniverse.SlideMenuController", "class_dr_universe_1_1_slide_menu_controller.html", null ],
    [ "DrUniverse.TutorialOverlay", "class_dr_universe_1_1_tutorial_overlay.html", null ],
    [ "UIApplicationDelegate", null, [
      [ "DrUniverse.AppDelegate", "class_dr_universe_1_1_app_delegate.html", null ]
    ] ],
    [ "UIPickerViewModel", null, [
      [ "DrUniverse.LogTesting.StatusPickerViewModel", "class_dr_universe_1_1_log_testing_1_1_status_picker_view_model.html", null ]
    ] ],
    [ "UITableViewCell", null, [
      [ "DrUniverse.BubbleCell", "class_dr_universe_1_1_bubble_cell.html", null ]
    ] ],
    [ "UIViewController", null, [
      [ "DrUniverse.AskSlideMenu", "class_dr_universe_1_1_ask_slide_menu.html", null ],
      [ "DrUniverse.GameSlideMenu", "class_dr_universe_1_1_game_slide_menu.html", null ],
      [ "DrUniverse.LogTesting", "class_dr_universe_1_1_log_testing.html", null ],
      [ "DrUniverse.RootViewController", "class_dr_universe_1_1_root_view_controller.html", null ],
      [ "DrUniverse.ViewScroll", "class_dr_universe_1_1_view_scroll.html", [
        [ "DrUniverse.AskPanelController", "class_dr_universe_1_1_ask_panel_controller.html", null ],
        [ "DrUniverse.ExplorePanelController", "class_dr_universe_1_1_explore_panel_controller.html", null ],
        [ "DrUniverse.QuestPanelController", "class_dr_universe_1_1_quest_panel_controller.html", null ]
      ] ]
    ] ]
];