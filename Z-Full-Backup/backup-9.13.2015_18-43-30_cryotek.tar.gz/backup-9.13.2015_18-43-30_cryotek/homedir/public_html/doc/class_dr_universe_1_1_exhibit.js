var class_dr_universe_1_1_exhibit =
[
    [ "estimote_id", "class_dr_universe_1_1_exhibit.html#a8de4a359675a33000ef9519bde1dbc37", null ],
    [ "id", "class_dr_universe_1_1_exhibit.html#a519e58efbebe637e276b663cc751ecae", null ],
    [ "image", "class_dr_universe_1_1_exhibit.html#a92745ed88e15792188efe58c0f17bc13", null ],
    [ "information", "class_dr_universe_1_1_exhibit.html#a6a043bde44529b9e432cb912fd075de4", null ],
    [ "intro", "class_dr_universe_1_1_exhibit.html#a45744993929285cbcfe4782e14104745", null ],
    [ "name", "class_dr_universe_1_1_exhibit.html#a6c10e578c92349c215936faebdf924ae", null ]
];