var class_dr_universe_1_1_ask_menu_controller =
[
    [ "ReleaseDesignerOutlets", "class_dr_universe_1_1_ask_menu_controller.html#ac8b651eae22495834b0a71ce2d99e6ae", null ],
    [ "button_test1", "class_dr_universe_1_1_ask_menu_controller.html#afdf18c0a7218665919bb7c895ae6dd11", null ],
    [ "button_test2", "class_dr_universe_1_1_ask_menu_controller.html#a978b3159700ed6e03a20b20d48f78ccd", null ],
    [ "image_background", "class_dr_universe_1_1_ask_menu_controller.html#a1d3192e8c44ab3b4755fc8511394281b", null ]
];