var class_dr_universe_1_1_app_delegate =
[
    [ "DidEnterBackground", "class_dr_universe_1_1_app_delegate.html#a120c18de2ab40e7599c2b10d3bf23c54", null ],
    [ "OnResignActivation", "class_dr_universe_1_1_app_delegate.html#a1414744187b31bbb7d45ef6f8cc57af0", null ],
    [ "WillEnterForeground", "class_dr_universe_1_1_app_delegate.html#ac5683e249412c959af9f0097a26954f4", null ],
    [ "WillTerminate", "class_dr_universe_1_1_app_delegate.html#a903f7facb0db6ea8ce848edaab0c50e8", null ],
    [ "Window", "class_dr_universe_1_1_app_delegate.html#a51d06d39e8b40bdc9277503dac4b8fd7", null ]
];