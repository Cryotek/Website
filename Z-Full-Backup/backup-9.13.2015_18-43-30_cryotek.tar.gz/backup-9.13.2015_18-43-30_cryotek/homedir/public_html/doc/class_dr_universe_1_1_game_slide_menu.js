var class_dr_universe_1_1_game_slide_menu =
[
    [ "GameSlideMenu", "class_dr_universe_1_1_game_slide_menu.html#a88cd232a8de6bfd5fa6a70d927c1b4eb", null ],
    [ "ReleaseDesignerOutlets", "class_dr_universe_1_1_game_slide_menu.html#a8928725a85c0645801dbb28743adadbe", null ],
    [ "ViewDidLoad", "class_dr_universe_1_1_game_slide_menu.html#a0f7cd1513bf32849d43ccd5b12f30f58", null ],
    [ "AskPanelMenu", "class_dr_universe_1_1_game_slide_menu.html#a80932e7baf33fb9ee6f8b9788f20266b", null ],
    [ "button_home", "class_dr_universe_1_1_game_slide_menu.html#a753d1f50276d8f57d89cf6b830eccf8a", null ],
    [ "button_reset", "class_dr_universe_1_1_game_slide_menu.html#a4c37b68b9abcd88175f31e9d24994b4a", null ],
    [ "image_background", "class_dr_universe_1_1_game_slide_menu.html#a5c2978b26242cfa7ed23c5069da66b67", null ],
    [ "image_bottomMenu", "class_dr_universe_1_1_game_slide_menu.html#a0e1aacb4ba19ec148aa0eeb8ad09b6cf", null ],
    [ "image_slideTopBanner", "class_dr_universe_1_1_game_slide_menu.html#af1d271875c782eba8479c01bf55fefcb", null ]
];