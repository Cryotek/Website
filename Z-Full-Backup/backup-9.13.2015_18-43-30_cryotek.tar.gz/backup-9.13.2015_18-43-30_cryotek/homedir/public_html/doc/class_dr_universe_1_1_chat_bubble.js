var class_dr_universe_1_1_chat_bubble =
[
    [ "ChatBubble", "class_dr_universe_1_1_chat_bubble.html#a53c3c044cea3bb3a25306f5b8ce49f96", null ],
    [ "GetCell", "class_dr_universe_1_1_chat_bubble.html#a54b40efd9bddd28c7dd6e398eb947616", null ],
    [ "GetHeight", "class_dr_universe_1_1_chat_bubble.html#adc3863d1c57a1be79a05f3cc4223ec5f", null ],
    [ "isLeft", "class_dr_universe_1_1_chat_bubble.html#ae4e3c1e275a7bc284027990b1146744c", null ]
];