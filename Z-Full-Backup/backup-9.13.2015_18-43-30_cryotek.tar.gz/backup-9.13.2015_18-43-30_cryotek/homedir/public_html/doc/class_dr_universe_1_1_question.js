var class_dr_universe_1_1_question =
[
    [ "aID", "class_dr_universe_1_1_question.html#a163c0af2b326533f6cd523e1a26f851c", null ],
    [ "qID", "class_dr_universe_1_1_question.html#ad68cab9a42f36e08f77caccc2a69277b", null ],
    [ "question", "class_dr_universe_1_1_question.html#aada4cff33ec157e1507801f7eb8a9975", null ],
    [ "question_es", "class_dr_universe_1_1_question.html#a29b87ce365c74dab3005efaa0db6657d", null ]
];