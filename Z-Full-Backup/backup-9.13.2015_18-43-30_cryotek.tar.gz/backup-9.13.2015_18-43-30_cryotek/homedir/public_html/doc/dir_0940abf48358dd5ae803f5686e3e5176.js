var dir_0940abf48358dd5ae803f5686e3e5176 =
[
    [ "obj", "dir_f39f6a35449b057801238ef1c3820d73.html", "dir_f39f6a35449b057801238ef1c3820d73" ],
    [ "Properties", "dir_62628bd5ad4d66e374ad6d16b3339c69.html", "dir_62628bd5ad4d66e374ad6d16b3339c69" ],
    [ "AdminWebPage.designer.cs", "_admin_web_page_8designer_8cs.html", [
      [ "AdminWebPage", "class_dr_universe_1_1_admin_web_page.html", "class_dr_universe_1_1_admin_web_page" ]
    ] ],
    [ "AppDelegate.cs", "_app_delegate_8cs.html", [
      [ "AppDelegate", "class_dr_universe_1_1_app_delegate.html", "class_dr_universe_1_1_app_delegate" ]
    ] ],
    [ "AskMenuController.designer.cs", "_ask_menu_controller_8designer_8cs.html", [
      [ "AskMenuController", "class_dr_universe_1_1_ask_menu_controller.html", "class_dr_universe_1_1_ask_menu_controller" ]
    ] ],
    [ "AskPanelController.cs", "_ask_panel_controller_8cs.html", [
      [ "AskPanelController", "class_dr_universe_1_1_ask_panel_controller.html", "class_dr_universe_1_1_ask_panel_controller" ]
    ] ],
    [ "AskPanelController.designer.cs", "_ask_panel_controller_8designer_8cs.html", [
      [ "AskPanelController", "class_dr_universe_1_1_ask_panel_controller.html", "class_dr_universe_1_1_ask_panel_controller" ]
    ] ],
    [ "AskPanelTutorial.cs", "_ask_panel_tutorial_8cs.html", [
      [ "AskPanelTutorial", "class_dr_universe_1_1_ask_panel_tutorial.html", "class_dr_universe_1_1_ask_panel_tutorial" ]
    ] ],
    [ "AskSlideMenu.cs", "_ask_slide_menu_8cs.html", [
      [ "AskSlideMenu", "class_dr_universe_1_1_ask_slide_menu.html", "class_dr_universe_1_1_ask_slide_menu" ]
    ] ],
    [ "AskSlideMenu.designer.cs", "_ask_slide_menu_8designer_8cs.html", [
      [ "AskSlideMenu", "class_dr_universe_1_1_ask_slide_menu.html", "class_dr_universe_1_1_ask_slide_menu" ]
    ] ],
    [ "AskSlideMenuController.cs", "_ask_slide_menu_controller_8cs.html", [
      [ "AskSlideMenuController", "class_dr_universe_1_1_ask_slide_menu_controller.html", "class_dr_universe_1_1_ask_slide_menu_controller" ]
    ] ],
    [ "AskSlideMenuController.designer.cs", "_ask_slide_menu_controller_8designer_8cs.html", [
      [ "AskSlideMenuController", "class_dr_universe_1_1_ask_slide_menu_controller.html", "class_dr_universe_1_1_ask_slide_menu_controller" ]
    ] ],
    [ "Bubble.cs", "_bubble_8cs.html", [
      [ "BubbleCell", "class_dr_universe_1_1_bubble_cell.html", "class_dr_universe_1_1_bubble_cell" ],
      [ "ChatBubble", "class_dr_universe_1_1_chat_bubble.html", "class_dr_universe_1_1_chat_bubble" ]
    ] ],
    [ "ClassInit.cs", "_class_init_8cs.html", [
      [ "Question", "class_dr_universe_1_1_question.html", "class_dr_universe_1_1_question" ],
      [ "Answer", "class_dr_universe_1_1_answer.html", "class_dr_universe_1_1_answer" ],
      [ "Estimote", "class_dr_universe_1_1_estimote.html", "class_dr_universe_1_1_estimote" ],
      [ "Exhibit", "class_dr_universe_1_1_exhibit.html", "class_dr_universe_1_1_exhibit" ],
      [ "Log", "class_dr_universe_1_1_log.html", "class_dr_universe_1_1_log" ],
      [ "Response", "class_dr_universe_1_1_response.html", "class_dr_universe_1_1_response" ]
    ] ],
    [ "DBHandler.cs", "_d_b_handler_8cs.html", null ],
    [ "ExplorePanelController.cs", "_explore_panel_controller_8cs.html", [
      [ "ExplorePanelController", "class_dr_universe_1_1_explore_panel_controller.html", "class_dr_universe_1_1_explore_panel_controller" ],
      [ "SimpleDataSource", "class_dr_universe_1_1_explore_panel_controller_1_1_simple_data_source.html", "class_dr_universe_1_1_explore_panel_controller_1_1_simple_data_source" ],
      [ "SimpleDelegate", "class_dr_universe_1_1_explore_panel_controller_1_1_simple_delegate.html", "class_dr_universe_1_1_explore_panel_controller_1_1_simple_delegate" ]
    ] ],
    [ "ExplorePanelController.designer.cs", "_explore_panel_controller_8designer_8cs.html", [
      [ "ExplorePanelController", "class_dr_universe_1_1_explore_panel_controller.html", "class_dr_universe_1_1_explore_panel_controller" ]
    ] ],
    [ "ExploreSlideMenuController.cs", "_explore_slide_menu_controller_8cs.html", [
      [ "ExploreSlideMenuController", "class_dr_universe_1_1_explore_slide_menu_controller.html", "class_dr_universe_1_1_explore_slide_menu_controller" ]
    ] ],
    [ "ExploreSlideMenuController.designer.cs", "_explore_slide_menu_controller_8designer_8cs.html", [
      [ "ExploreSlideMenuController", "class_dr_universe_1_1_explore_slide_menu_controller.html", "class_dr_universe_1_1_explore_slide_menu_controller" ]
    ] ],
    [ "GameSlideMenu.cs", "_game_slide_menu_8cs.html", [
      [ "GameSlideMenu", "class_dr_universe_1_1_game_slide_menu.html", "class_dr_universe_1_1_game_slide_menu" ]
    ] ],
    [ "GameSlideMenu.designer.cs", "_game_slide_menu_8designer_8cs.html", [
      [ "GameSlideMenu", "class_dr_universe_1_1_game_slide_menu.html", "class_dr_universe_1_1_game_slide_menu" ]
    ] ],
    [ "LogHandler.cs", "_log_handler_8cs.html", null ],
    [ "LogTesting.cs", "_log_testing_8cs.html", [
      [ "LogTesting", "class_dr_universe_1_1_log_testing.html", "class_dr_universe_1_1_log_testing" ],
      [ "StatusPickerViewModel", "class_dr_universe_1_1_log_testing_1_1_status_picker_view_model.html", "class_dr_universe_1_1_log_testing_1_1_status_picker_view_model" ]
    ] ],
    [ "LuceneSearch.cs", "_lucene_search_8cs.html", null ],
    [ "Main.cs", "_main_8cs.html", [
      [ "Application", "class_dr_universe_1_1_application.html", null ]
    ] ],
    [ "Network.cs", "_network_8cs.html", "_network_8cs" ],
    [ "QuestionBar.cs", "_question_bar_8cs.html", [
      [ "QuestionBar", "class_dr_universe_1_1_question_bar.html", "class_dr_universe_1_1_question_bar" ]
    ] ],
    [ "QuestPanelController.cs", "_quest_panel_controller_8cs.html", [
      [ "QuestPanelController", "class_dr_universe_1_1_quest_panel_controller.html", "class_dr_universe_1_1_quest_panel_controller" ]
    ] ],
    [ "QuestPanelController.designer.cs", "_quest_panel_controller_8designer_8cs.html", [
      [ "QuestPanelController", "class_dr_universe_1_1_quest_panel_controller.html", "class_dr_universe_1_1_quest_panel_controller" ]
    ] ],
    [ "QuestScene.cs", "_quest_scene_8cs.html", [
      [ "QuestScene", "class_dr_universe_1_1_quest_scene.html", "class_dr_universe_1_1_quest_scene" ]
    ] ],
    [ "QuestSlideMenuController.cs", "_quest_slide_menu_controller_8cs.html", [
      [ "QuestSlideMenuController", "class_dr_universe_1_1_quest_slide_menu_controller.html", "class_dr_universe_1_1_quest_slide_menu_controller" ]
    ] ],
    [ "QuestSlideMenuController.designer.cs", "_quest_slide_menu_controller_8designer_8cs.html", [
      [ "QuestSlideMenuController", "class_dr_universe_1_1_quest_slide_menu_controller.html", "class_dr_universe_1_1_quest_slide_menu_controller" ]
    ] ],
    [ "RootViewController.cs", "_root_view_controller_8cs.html", [
      [ "RootViewController", "class_dr_universe_1_1_root_view_controller.html", "class_dr_universe_1_1_root_view_controller" ]
    ] ],
    [ "RootViewController.designer.cs", "_root_view_controller_8designer_8cs.html", [
      [ "RootViewController", "class_dr_universe_1_1_root_view_controller.html", "class_dr_universe_1_1_root_view_controller" ]
    ] ],
    [ "SlideMenuController.designer.cs", "_slide_menu_controller_8designer_8cs.html", [
      [ "SlideMenuController", "class_dr_universe_1_1_slide_menu_controller.html", "class_dr_universe_1_1_slide_menu_controller" ]
    ] ],
    [ "TutorialOverlay.cs", "_tutorial_overlay_8cs.html", [
      [ "TutorialOverlay", "class_dr_universe_1_1_tutorial_overlay.html", "class_dr_universe_1_1_tutorial_overlay" ]
    ] ],
    [ "ViewScroll.cs", "_view_scroll_8cs.html", [
      [ "ViewScroll", "class_dr_universe_1_1_view_scroll.html", "class_dr_universe_1_1_view_scroll" ]
    ] ]
];